# csv_upload
Updating modals in Django using csv upload
